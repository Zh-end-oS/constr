import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Профиль",
  description: "",
};

export default function Profile() {
  return <div>Profile Page</div>;
}
