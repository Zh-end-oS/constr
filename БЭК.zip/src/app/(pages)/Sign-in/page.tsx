import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Воход | Регистрация",
  description: "",
};

export default function SignIn() {
  return <div>Sign in Page</div>;
}
