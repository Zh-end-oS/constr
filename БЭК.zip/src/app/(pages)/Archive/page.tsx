import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Архив статей",
  description: "",
};

export default function ArchivePage() {
  return <div>Archive Page</div>;
}
