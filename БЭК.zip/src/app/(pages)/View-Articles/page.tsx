import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Опубликованные  статьи",
  description: "",
};

export default function ViewArticles() {
  return <div>View Articles Page</div>;
}
