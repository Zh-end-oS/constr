import Link from 'next/link';
import "./the.header.style.scss";

const TheHeader = () => {
    return (
        <header>
            <Link className='logo' href="/"><h1>LOGO</h1></Link>
            <Link href="/">Home</Link>
            <Link href="/Library">Library</Link>
            <Link href="/Constructor">Constructor</Link>
            <Link href="/View-Articles">View Articles</Link>
            <Link href="/Archive">Archive</Link>
            <Link href="/Profile">Profile</Link>
            <Link href="/Sign-in">Sign in</Link>
            {/* <h4>log out</h4> */}
        </header>
    )
}

export {TheHeader}